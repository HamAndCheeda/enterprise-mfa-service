// Express web framework and types
import express, { Request, Response } from 'express';
// otplib provides TOTP generation and validation following RFC6238
import { authenticator } from 'otplib';
// bcrypt for hashing/validating backup codes and passwords
import bcrypt from 'bcrypt';
// jsonwebtoken for issuing short-lived and session tokens
import jwt from 'jsonwebtoken';
// dotenv loads environment variables from .env during local development
import dotenv from 'dotenv';
// qrcode library used to produce a data-URL PNG for the otpauth URI (scannable by authenticator apps).
// Import via require to avoid missing TypeScript declaration errors at runtime.
/* eslint-disable @typescript-eslint/no-var-requires */
const QRCode = require('qrcode');
// Utilities for filesystem paths and file operations
import path from 'path';
import fs from 'fs';

// Load .env values into process.env (only used in development/test)
dotenv.config();

// Initialize Express app and middleware
const app = express();
app.use(express.json());
// Serve the minimal static UI used for testing in the `public` folder
app.use(express.static(path.join(process.cwd(), 'public')));

// Secrets; in production these must come from a secret store or environment variables
const JWT_SECRET = process.env.JWT_SECRET || 'super-secret-jwt-key-change-in-prod';
const PRE_AUTH_SECRET = process.env.PRE_AUTH_SECRET || 'pre-auth-temp-secret-key';
// Port the service listens on (configurable via .env)
const PORT = Number(process.env.PORT || 3000);

// Simple JSON file-backed storage for users. This is intentionally minimal and
// suitable only for local testing. Replace with a proper database for any
// real deployment.
const dataDir = path.join(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const usersFile = path.join(dataDir, 'users.json');

// User shape stored in the JSON file. backupCodeHashes contains bcrypt-hashed
// backup codes (single-use). totpSecret is the base32 secret used by TOTP.
type User = {
    username: string;
    passwordHash: string;
    mfaEnabled: boolean;
    totpSecret?: string;
    backupCodeHashes?: string[];
};

// In-memory mirror of the users file for fast access. We persist changes with
// persistUsers() so data survives restarts.
let usersStore: Record<string, User> = {};
try {
    if (fs.existsSync(usersFile)) {
        const raw = fs.readFileSync(usersFile, 'utf8') || '{}';
        usersStore = JSON.parse(raw);
    }
} catch (err) {
    usersStore = {};
}

function persistUsers() {
    // Write the users file in a readable JSON format; in production you would
    // use a transactional DB and not a plain file write.
    fs.writeFileSync(usersFile, JSON.stringify(usersStore, null, 2), 'utf8');
}

function getUser(username: string): User | undefined {
    const u = usersStore[username];
    return u ? { ...u } : undefined; // return a shallow copy to avoid accidental mutation
}

function saveUser(user: User) {
    usersStore[user.username] = user;
    persistUsers();
}

// Track failed attempts (by username) to implement temporary lockout after a
// number of consecutive failures. This is a simple in-memory counter used for
// demo; a production system would store these metrics in a resilient store.
const failedAttemptsMap = new Map<string, { count: number; lockoutUntil: number }>();

// Helper to generate human-readable backup codes and their bcrypt hashes.
// Backup codes are single-use: we store only the hashes and return the
// plaintext codes once so the user can save them.
async function createBackupCodes(count = 5) {
    const codes: string[] = [];
    const hashes: string[] = [];
    for (let i = 0; i < count; i++) {
        const code = Math.random().toString(36).slice(-8).toUpperCase();
        codes.push(code);
        hashes.push(await bcrypt.hash(code, 10));
    }
    return { codes, hashes };
}

// --- Phase 1: Primary Login Endpoint ---
// Phase 1: Primary login endpoint. Verifies username/password and, if the
// user has MFA enabled, returns a short-lived pre_auth token. The pre_auth
// token must be presented to the /mfa/verify endpoint to complete login.
app.post('/api/v1/auth/login', async (req: Request, res: Response): Promise<any> => {
    const { username, password } = req.body || {};
    if (typeof username !== 'string' || typeof password !== 'string') {
        return res.status(400).json({ error: 'Invalid request' });
    }

    const user = getUser(username);
    // Generic error to avoid leaking whether a user exists
    if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    const passwordOk = await bcrypt.compare(password, user.passwordHash);
    if (!passwordOk) {
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (user.mfaEnabled) {
        // On successful primary auth, issue a short-lived pre-auth token that
        // proves the user passed the password step but not yet the MFA.
        const preAuthToken = jwt.sign(
            { username: user.username, type: 'pre_auth' },
            PRE_AUTH_SECRET,
            { expiresIn: '5m' }
        );

        return res.status(200).json({
            mfa_required: true,
            pre_auth_token: preAuthToken,
            expires_in_seconds: 300
        });
    }

    // No MFA configured: issue a full session token directly
    const sessionToken = jwt.sign({ username: user.username }, JWT_SECRET, { expiresIn: '1h' });
    return res.status(200).json({ mfa_required: false, access_token: sessionToken });
});

// --- Enrollment Endpoint: generate TOTP secret, otpauth URL, QR and backup codes ---
// Enrollment endpoint: called by the client UI to provision a TOTP secret for
// a user. This endpoint verifies the user's password, generates a new secret,
// returns an otpauth URL and a QR data URL that the user can scan with their
// authenticator app. Backup codes are created and their hashes are stored.
app.post('/api/v1/auth/mfa/enroll', async (req: Request, res: Response): Promise<any> => {
    const { username, password } = req.body || {};
    if (typeof username !== 'string' || typeof password !== 'string') {
        return res.status(400).json({ error: 'Invalid request' });
    }

    const user = getUser(username);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const passwordOk = await bcrypt.compare(password, user.passwordHash);
    if (!passwordOk) return res.status(401).json({ error: 'Invalid credentials' });

    // Generate secret and otpauth URI usable by authenticator apps
    const secret = authenticator.generateSecret();
    const otpauth = authenticator.keyuri(username, 'Enterprise MFA Service', secret);

    // Convert otpauth URI to an image data URL the browser can render directly
    let qrCodeDataUrl: string;
    try {
        qrCodeDataUrl = await QRCode.toDataURL(otpauth);
    } catch (err) {
        return res.status(500).json({ error: 'Failed to generate QR code' });
    }

    // Create one-time backup codes and persist their hashes
    const { codes, hashes } = await createBackupCodes(5);

    // Persist the new TOTP secret and hashed backup codes on the user record.
    user.totpSecret = secret;
    user.backupCodeHashes = hashes;
    user.mfaEnabled = true;
    saveUser(user);

    // Return the otpauth URL (for manual entry), a QR data URL (for scanning),
    // and the plaintext backup codes (display to user one-time only).
    return res.status(200).json({
        otpauth_url: otpauth,
        qr_code_data_url: qrCodeDataUrl,
        backup_codes: codes
    });
});

// --- Phase 2: MFA Verification Endpoint ---
// Phase 2: MFA verification. Accepts a pre_auth token (issued from login)
// and a TOTP or backup code. On success issues a full session token.
app.post('/api/v1/auth/mfa/verify', async (req: Request, res: Response): Promise<any> => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing pre_auth_token' });
    }

    const preAuthToken = authHeader.split(' ')[1];

    try {
        // Verify pre_auth_token is valid and of correct type
        const decoded: any = jwt.verify(preAuthToken, PRE_AUTH_SECRET);
        if (decoded.type !== 'pre_auth') {
            return res.status(403).json({ error: 'Invalid token type' });
        }

        const user = getUser(decoded.username);
        if (!user || !user.totpSecret) {
            return res.status(400).json({ error: 'MFA configuration not found' });
        }

        // Simple brute-force mitigation: per-user counters and temporary lockout
        const clientKey = decoded.username;
        const now = Date.now();
        const record = failedAttemptsMap.get(clientKey);

        if (record && record.lockoutUntil > now) {
            const remainingSecs = Math.ceil((record.lockoutUntil - now) / 1000);
            return res.status(429).json({ error: `Account temporarily locked due to failed attempts. Try again in ${remainingSecs}s.` });
        }

        const { code, is_backup_code } = req.body || {};
        if (typeof code !== 'string') return res.status(400).json({ error: 'Invalid code' });

        let isValid = false;

        if (is_backup_code) {
            // If using a backup code, compare against stored bcrypt hashes and
            // enforce single-use by removing the used one.
            for (let i = 0; i < (user.backupCodeHashes?.length || 0); i++) {
                const match = await bcrypt.compare(code, user.backupCodeHashes![i]);
                if (match) {
                    isValid = true;
                    user.backupCodeHashes!.splice(i, 1);
                    saveUser(user); // persist the consumed backup code
                    break;
                }
            }
        } else {
            // Validate standard TOTP (allow a small clock-drift window)
            authenticator.options = { window: 1 };
            isValid = authenticator.check(code, user.totpSecret as string);
        }

        if (!isValid) {
            // Increment failure counter and apply temporary lockout after threshold
            const currentRecord = failedAttemptsMap.get(clientKey) || { count: 0, lockoutUntil: 0 };
            currentRecord.count += 1;

            if (currentRecord.count >= 5) {
                currentRecord.lockoutUntil = now + 15 * 60 * 1000; // 15 minutes
                currentRecord.count = 0;
            }
            failedAttemptsMap.set(clientKey, currentRecord);

            return res.status(400).json({ error: 'Invalid verification code' });
        }

        // On success, clear failures and issue a full session token
        failedAttemptsMap.delete(clientKey);
        const sessionToken = jwt.sign({ username: user.username }, JWT_SECRET, { expiresIn: '1h' });
        return res.status(200).json({
            access_token: sessionToken,
            token_type: 'Bearer',
            expires_in: 3600
        });

    } catch (err) {
        return res.status(401).json({ error: 'Invalid or expired pre_auth_token' });
    }
});

// Seed a mock user for testing (hashed password and backup codes)
// Seed a test user on first run. In production remove this logic and create
// real users through your registration flow or admin tooling.
(async () => {
    const passwordHash = await bcrypt.hash('ValidPassword123!', 10);
    const { codes, hashes } = await createBackupCodes(5);
    const seededUser: User = {
        username: 'user@enterprise.com',
        passwordHash,
        mfaEnabled: true,
        totpSecret: authenticator.generateSecret(), // base32 secret
        backupCodeHashes: hashes
    };
    saveUser(seededUser);

    // Print the one-time backup codes so a developer can test quickly. These
    // are shown only on startup and are not stored in plaintext.
    console.log('Seeded user: user@enterprise.com');
    console.log('One-time backup codes (store safely):', codes);
})();

// Start the HTTP server. The test UI is available at /index.html
app.listen(PORT, () => {
    console.log(`MFA Microservice running on port ${PORT}`);
});
