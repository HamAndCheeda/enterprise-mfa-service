declare module 'qrcode';
